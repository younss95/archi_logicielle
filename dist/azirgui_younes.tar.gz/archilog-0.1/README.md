# archilog

A simple project for educational purpose.

```bash
$ pdm run archilog
Usage: archilog [OPTIONS] COMMAND [ARGS]...

Options:
  --help  Show this message and exit.

Commands:
  create
  delete
  get
  get-all
  import-csv
  init-db
  update
```

Course & examples : [https://kathode.neocities.org](https://kathode.neocities.org)